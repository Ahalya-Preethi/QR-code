<?php
$host="localhost";
$user="root";
$password="";
$db_name="loginqr";
$con=mysqli_connect($host,$user,$password,$db_name);
if(mysqli_connect_errno()){
die("FAILED TO CONNECT WITH MYSQL: ".mysqli_connect_err());
}
?>